<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>无陌然文章伪原创-免费在线文章伪原创</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="shortcut icon" href="http://link.aidezy.com/favicon.ico" type="image/x-icon" />
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <script type="text/javascript" src="js/jquery.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="author" content="Wu MoRan">
</head>
<body>
  <div class="container-fluid">
    <div class="row">
<ul class="nav nav-tabs daohang">
  <a href="/index.php"> <img class="img-rounded logo" src="img/logo.png" ></a>
 
 
  <div class="leibiao">
  
  <li role="presentation"><a href="http://video.aidezy.com">无陌然视频解析</a></li>
  <li role="presentation"><a href="http://php.aidezy.com">无陌然PHP加密</a></li>
  <li role="presentation"><a href="http://blog.aidezy.com">无陌然个人博客</a></li>
  <li role="presentation"><a href="http://aidezy.com">AIDE技术网</a></li>
  </div>
<span class="lo glyphicon glyphicon-align-justify shou" aria-hidden="true"></span>

</ul>

<!-- 手机导航 -->
<div class="col-xs-12 shoujihang" style="display: none;">
  <div class="soleibiao">

   <li role="presentation"><a href="http://video.aidezy.com">无陌然视频解析</a></li>  <li role="presentation"><a href="http://php.aidezy.com">无陌然PHP加密</a></li>
  <li role="presentation"><a href="http://blog.aidezy.com">无陌然个人博客</a></li>
  <li role="presentation"><a href="http://aidezy.com">AIDE技术网</a></li>
  </div>
</div>
</div>

</div>

  <div class="jumbotron">
  <h1>文章在线免费伪原创</h1>
  <br>
  <p>唯一域名:UQSEO.CN</p>

</div>

  <div class="container-fluid">

<div class="bs-callout bs-callout-info" id="callout-navs-tabs-plugin">
    <h4>SEO伪原创:</h4>


   <p style="color: black;"> <b>SEO在线免费伪原创&nbsp;&nbsp;<a id="cizu"><span id="liebiao" style="color: red;">点我返回伪原创</span></a></b></p>



<p><b>网站介绍:各位站长朋友想必都为网站内容原创的问题头疼吧，作为一个草根站长，要想自己写原创文章，那是不可能的，当然我不是说你一篇也写不出来。以个人站长的人力来说，写原创文章不太现实，光时间就是问题。
</b></p>

<p style="color: blue;"><b>会不会被K站?:有朋友问我，这样会不会被K，算不算做弊?

　　就这个问题我发表一下个人的看法供你参考。搜索引擎毕竟是机器，他抓取文章后会在数据库中与已有的文章做一个比对，如果发现有相似度很高的文章则认为是抄袭，反之认为是原创。当然如果你是原样照搬的，那么就订死是抄袭的。用伪原创工具转换后，文章中的部分词组被转换成同义词，搜索引擎再比对时，就认为是原创文章了。当然这也不是绝对的，看具体转换词组多少而言。
<br>

</b></p>
<p>用法：把文章粘贴到编辑器中，点击转换，则文章中的部分词组会被替换掉，以实现伪原创的目的。</p>
  </div>


<?php 
require('./include/keyword.php');
$tq = array_keys($keyword_arr);
$th = array_values($keyword_arr);
$key = array_search('瞭望', $tq);
$houzhi = $th[$key];
// foreach ($keyword_arr as $key => $value) {
// 	print_r($key);
// }
/**
* 生成授权域名分页
* @param int $num 文章总数
* @param int $curr 当前显示的页码数      $curr-2 $curr-1 $curr $curr+1 $curr+2
* @param int $cnt 每页显示的条数
*/

function sgetPage($num,$curr,$cnt) {
	//最大的页码数
	$max = ceil($num/$cnt);
	//最左侧页码
	$left = max(1 , $curr-2);

	//最右侧页码
	$right = min($left+4 , $max);

	$left = max(1 , $right-4);

/*	(1 [2] 3 4 5) 6 7 8 9 
	1 2 (3 4 [5] 6 7) 8 9
	1 2 3 4 (5 6 7 [8] 9)*/
	//$page = array();
	for($i=$left;$i<=$right;$i++) {
		//$page[$i] = 'page='.$i;
		
		$_GET['spage'] = $i;
 		$page[$i] = http_build_query($_GET);

 		//$page[$i] = http_build_query($_GET['page'] = $i);
	}

	return $page;
}

$dapage = isset($_GET['spage'])?$_GET['spage']:1;
$pagesize = 10;
$count = count($keyword_arr);//总条数
$start=($dapage-1)*$pagesize;//偏移量，当前页-1乘以每页显示条数
$article = array_slice($keyword_arr,$start,$pagesize);
$page = sgetPage($count , $dapage , $pagesize);
$zyes = $count/$pagesize;



$path ="tongyi.php";
$content = "<script>alert(1);</script>";




 ?>

<div class="row tian">
  <div class=".col-lg-1">
<div class="bs-example" data-example-id="panel-without-body-with-table">
    <div class="panel panel-default">
      <!-- Default panel contents -->
      <div class="panel-heading">词组</div>

      <!-- Table -->
      <table class="table">
        <thead>
          <tr>
            <th>序号</th>
            <th>词语</th>
            <!-- <th>Last Name</th> -->
            <th>同义词</th>
          </tr>
        </thead>
        <tbody>

        	<?php 
        	$shuzu = 1;
        	foreach ($article as $key => $value) {?>
          <tr>
            <th scope="row"><?php echo $shuzu ?></th>
            <td><?php echo $key ?></td>
            <!-- <td>Otto</td> -->
            <td><?php echo $value ?></td>
          </tr>
			<?php
			$shuzu = $shuzu + 1;
			 }?>
        </tbody>
      </table>
    </div>
  </div>



<ul class="pagination" style="    margin: 0px 0 0 0px; display: block;">
  <li class="disabled">
      <?php foreach($page as $k=>$v) {?>
  <?php if($k == $dapage) {?>
    <a href="list.php?spage=<?php echo 1 ?>">首页</a>
  </li>
<?php if($k == 1){?>
  <li class="disabled"><a href="list.php?spage=1">«</a></li>
  <?php } else if($k > 1){?>
 <li class="disabled"><a href="list.php?spage=<?php echo $k - 1;?>">«</a></li>
  <?php }?>
  <li class="disabled"><a><?php echo $k;?></a>
    <?php if($k == $zyes){?>
  </li><li class="disabled"><a href="list.php?spage=<?php echo $zyes ?>">»</a></li>
  <?php } else if($k < $zyes){?>
</li><li class="disabled"><a href="list.php?spage=<?php echo $k+1;?>">»</a></li>
  <?php }?>
  <li class="disabled"><a href="list.php?spage=<?php echo ceil($zyes) ?>">尾页</a></li>
  <?php }?>
      <?php }?>
</ul>


  <br>
<br>
 <br>
<span style="color: black;">提交同义词<span>例如:&nbsp;<b>原创-首创</b>&nbsp;</span></span>
<br><br>
<span style="color: black;">查找是否存在词语<span>例如:&nbsp;<b>输入已经有的'原创'返回'<span style="color: red;">词库已经存在该词语</span>'</b>&nbsp;</span></span>
<br>
<br>

<!-- <input type="" name="" value="" id="ym"> -->
  <input style=" display: inline; width:25%;"  id="tong" type="txt" class="form-control" id="exampleInputEmail1" placeholder="输入同义词">
  &nbsp;
  &nbsp;

  <!-- <input name="submit" type="submit" name="button" id="button" value="点击生成伪原创" /> -->
  <input type="button" style=" width:7%;  height: 35px;" id="tongyi" name="tongyi"  class="btn btn-success" value="提交"/>
    <input type="button" style=" width:7%;  height: 35px;"  id="tongyijian" name="tongyijian" class="btn btn-success" value="检查"/>
  <!-- <input style="    height: 35px;" name="submit" type="reset" class="btn btn-success" value="清除"/> -->

    </form>
<br><br>

  </div>
</div>

    </div>

</body>




<script type="text/javascript">




$('#tongyi').click(function(){
  if ($('#tong').val() == '') {
  alert('请输入后在提交');
  return false; }
  var data = {};
  data.nr = $('#tong').val();
  var url = 'tongyi.php';
  $.post(url , data , function(msg , msg2 , msg3){
    if (msg3.readyState == 4) {
      if (msg3.responseText == 1) {
        $('#tong').val('提交成功,感谢!');
        setTimeout(function(){
          $('#tong').val('');
        } , 2000);
      }else{
        $('#tong').val('提交失败啦,请重新提交一次,感谢你的支持!');
          setTimeout(function(){
          $('#tong').val('');
        } , 2000);
      }
    }
  });
});
$('#tongyijian').click(function(){
  if ($('#tong').val() == '') {
  alert('请输入后在提交');
  return false;}
  var data = {};
  data.jcnr = $('#tong').val();
  var url = 'tongyi.php';
  $.post(url , data , function(msg , msg2 ,msg3){
    if (msg3.readyState == 4) {
      if (msg3.responseText == 1) {
        $('#tong').val('词库已经存在该词语');
          setTimeout(function(){
          $('#tong').val('');
        } , 2000);
      }else{
        $('#tong').val('词库未收录,请提交');
          setTimeout(function(){
          $('#tong').val('');
        } , 2000);
      }
    }
  });
});




$('#cizu').click(function(){
	window.location = 'index.php';
});

</script>

<script type="text/javascript">
$('#aspku').submit(function(){
  var url = '2.php';
  var data = {};

  data.elm1 = $('#elm1').val();
  $.post(url , data , function(msg){
    $('#elm1').val(msg);
  });

  return false;
});

</script>

<script type="text/javascript">
$('.shou').click(function(){
  
    var zt = $('.shoujihang').css('display');

  if (zt == 'block') {
    $('.shoujihang').css('display' , 'none');
  }else{
    $('.shoujihang').css('display' , 'block');
  }
});
</script>
</html>