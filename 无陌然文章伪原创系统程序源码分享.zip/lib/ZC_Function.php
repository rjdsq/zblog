<?php
	
	
	//调用系统信息
	function get_index(){
		global $db;
		$sql="select * from `".PRE."system`";
		$rs=$db->query($sql) or die ("请到<a href='admin/AdminLogin.php'>后台</a>初始化系统");
		while($row=$db->fetch_array($rs)){
			return $row;
		}
	}
	//调用站点名字
	function web_name(){
		global $db;
		$sql="select * from `".PRE."system`";
		$rs=$db->query($sql) or die ("请到<a href='admin/AdminLogin.php'>后台</a>初始化系统");
		while($row=$db->fetch_array($rs)){
			echo $row['name'];
		}
	}
	
	//调用系统版权信息
	function copyright(){
		global $db;
		$sql="select * from `".PRE."system`";
		$rs=$db->query($sql) or die ("请到<a href='admin/AdminLogin.php'>后台</a>初始化系统");
		while($row=$db->fetch_array($rs)){
			echo $row['copyright'];
		}
	}
	
	//生成缩略图名字
	function create_spic($pic){
		$arr=explode("/",$pic);
		$pic_name=$arr[count($arr)-1];//取得去掉路径后的文件名
		$spic=str_replace($pic_name,"s_".$pic_name,$pic);//替换掉文件名
		return $spic;
	}
	//验证是否有管理员权限
	function check_admin($uid,$shell){
		if($uid&&$shell){
			$sql="select * from `".PRE."admin` where `id`=".intval($uid);
			$rs=mysql_query($sql) or die ("查询管理员信息出现错误");
			$ok=is_array($row=mysql_fetch_array($rs));
			$sll=$ok?$shell==md5($row['name'].$row['password'].aspku):false;
			if($sll){
				return $row;
			}else{
				echo "你无权进入该页面";
				exit();
			}
		}else{
			echo "你无权进入该页面";
			exit;
		}
		
	}
	
	//格式化时间
	function format_date($str,$num){
		$str=$str+(8*60*60);//我用的国外空间，时间相差8个小时，你们可以自己更改
		switch ($num) {
			case 1:
				return date('Y-m-d',$str);//2009-08-02 
				break;
			case 2:
				return date('Y-m-d H:i:s',$str);//2009-08-02 10:45:03 
				break;
			case 3:
				return date('Y年m月d日',$str);//2009年08月02日 
				break;
			case 4:
				return date('m月d日',$str);//08月02日 
				break;
			default:
				return date('F j,Y,g:i a',$str);//August 2,2009,10:48 am  
		}
	}
	
	//过滤防注射字符
	//如果包含SQL字符则返回真，否则返回假
	function inject_check($str){
 		return eregi('select|insert|update|delete|\'|\/\*|\*|\.\.\/|\.\/|union|into|load_file|outfile', $str);	
	}
	
	//对提交参数的值进行验证
	//参数：str:需要验证的字符，参数：num，0为数字，其他为字符
	function safe_check($str,$num){
		if(!$str){
			exit('没有提交参数');//判断参数是否为空
		}
		if(inject_check($str)){
			exit('提交的参数非法');//注射判断
		}
		if($num==0){
			if(!is_numeric($str)){
				exit('提交参数非法');//判断是否为数字类型
			}else{
				$str=intval($str);//取整数
			}
		}else{
			 if (!get_magic_quotes_gpc()) {   
			   $str = mysql_real_escape_string($str); 
			 }   
		}
		return $str;
	}
	
	//格式化textarea输入并过滤
	function htmlarea($str){
		 if(empty($str)) return;
		 if($str=="") return $str;
		 $str=str_replace(chr(38),"&#38;",$str);
		 $str=str_replace(">","&gt;",$str);
		 $str=str_replace("<","&lt;",$str);
		 $str=str_replace(chr(39),"&#39;",$str);
		 $str=str_replace(chr(32),"&nbsp;",$str);
		 $str=str_replace(chr(34),"&quot;",$str);
		 $str=str_replace(chr(13),"",$str);
		 $str=str_replace(chr(10),"<br>",$str);
		 if (!get_magic_quotes_gpc()) {   
		   $str = mysql_real_escape_string($str);  
		 } 
		 return $str;
	}
	
	//清除textarea格式
	function area_clean($str){
		 if(empty($str)) return;
		 if($str=="") return $str;
		 $str=str_replace("&#38;",chr(38),$str);
		 $str=str_replace("&gt;",">",$str);
		 $str=str_replace("&lt;","<",$str);
		 $str=str_replace("&#39;",chr(39),$str);
		 $str=str_replace("&nbsp;",chr(32),$str);
		 $str=str_replace("&quot;",chr(34),$str);
		 $str=str_replace("",chr(13),$str);
		 $str=str_replace("<br>",chr(10),$str);
		 return $str;
	}
	
	function htmldecode($str){
		 if(empty($str)) return;
		 if($str=="") return $str;
		 
		 if (!get_magic_quotes_gpc()) {   
		   $str = mysql_real_escape_string($str);  
		 } 
		 return $str;
	}
	
	
	//过滤HTML格式
	function html_clean($content) {
		$content = htmlspecialchars($content);
		return $content;
	}
	
	//判断用户是否超时
	function overtime($in_time){
		$new_time=mktime();
		if($new_time-$in_time>1200){
			echo "由于你长时间未有任何操作，登录超时！";
			session_destroy();
			echo "<script language='javascript' >window.location.href='AdminLogin.php'</script>";
		}else{
			$_SESSION['in_time']=mktime();
		}		
	}
	
	//取得当前页面的页码,用于分页
	function get_page_num($sql,$pagesize){
		global $db;
		if(isset($_GET['page'])){
			$page=intval($_GET['page']);
		}else{
			$page=1;
		}
		
		if(!$page||$page<1){
			$page=1;
		}
		$totle=$db->num_rows($db->query($sql));
		$maxpage=ceil($totle/$pagesize);
		if($maxpage<1){
			$maxpage=1;
		}
		$page=$page>=$maxpage?$maxpage:$page;
		$firstpage=($page-1)*$pagesize;
		$arr=array($totle,$firstpage);
		return $arr;
	}
	//截取utf8字符串
	function str_len($str, $len) {    
		$i = 0;    
		$tlen = 0;    
		$tstr = '';    
		while ($tlen < $len) {    
			$chr = mb_substr($str, $i, 1, 'utf8');//mb_substr:按字符计算
			$chrLen = ord($chr) > 127 ? 2 : 1;    
			if ($tlen + $chrLen > $len) break;    
			$tstr .= $chr;    
			$tlen += $chrLen;    
			$i ++;    
		 }       
		return $tstr;    
	}  
	
	//生成SEO关键词文件
	function set_keywords(){
		global $db;
		$str="<?php\r\n";
		$str.="\$keyword_arr = array (\r\n";
		$sql="select * from `".PRE."keywords` order by id desc";							  
		$rs=$db->query($sql);
		while($row=$db->fetch_array($rs)){
			$str.="	'$row[keyword]' => '$row[replace]',";
		}
		$str.=");\r\n";
		$str.="?>\r\n";
		$filename='keyword.php';
		$handle=fopen($filename,"w");
		if(!is_writable($filename)){
			die ("文件：".$filename."不可写，请检查其属性后重试!");
		}
		if(!fwrite($handle,$str)){
			die ("生成文件".$filename."失败!");
		}
		fclose ($handle); //关闭指针		
	}
	
	//备份替换前内容
	function set_bak($str){
		$filename=time().'.php';
		$handle=fopen($filename,"w");
		if(!is_writable($filename)){
			die ("文件：".$filename."不可写，请检查其属性后重试!");
		}
		if(!fwrite($handle,$str)){
			die ("生成文件".$filename."失败!");
		}
		fclose ($handle); //关闭指针	
		if(unlink($filename)){
			die ("删除临时文件".$filename."失败!");
		}
	}

?>