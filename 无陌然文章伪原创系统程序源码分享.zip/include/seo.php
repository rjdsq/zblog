<?php
header("content-type:text/html; charset=utf-8"); 
include("config.php");
$link = mysql_connect(DB_HOST, DB_USER, DB_PASS) or die("数据库配置信息错误：" . mysql_error());
mysql_query("SET NAMES utf8");
if(!@mysql_select_db(DB_DATE, $link)){
	exit("数据库连接失败！");		
}
$ip=$_SERVER['REMOTE_ADDR'];
$time=time();
$arr=array();
$f= fopen("E:\\phpnow\\htdocs\\seo\\key.php","r");

while (!feof($f)){ 
	$line = fgets($f); 
	$line=trim($line);
	$line=str_replace('',' ',$line);
	$arr=explode("→",$line);
	$keyword=$arr[0];
	$replace=$arr[1];
	$sql="insert into `aspku_keywords`(`keyword`,`replace`,`addtime`,`ip`) values('".$keyword."','".$replace."','".$time."','".$ip."')";
	echo $sql."\r\n";
	mysql_query($sql) or die(mysql_error());
}
unset($arr);
fclose($f);
?>

