<?php
	define('DB_HOST', 'localhost'); //数据库服务器地址
	define('DB_DATE', 'seo'); //数据库名字
	define('DB_USER', 'seo'); //用户名
	define('DB_PASS', '123456'); //密码
	define('PRE','aspku_');//数据库前缀
	define('FCK_DIR','fckeditor');//定义编辑器路径
	define('aspku','aspku');//加密所用常量
?>
