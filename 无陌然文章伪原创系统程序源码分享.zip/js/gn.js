	$(function() {

			$('#queding').click(function(){

				if ($("#ym").val() == 0) {
					alert('请先输入域名在使用!');
					$('#inputstr').val('');
					return false;
				}else{
					var url = 'zidongneilian.php?url=' + $("#inputstr").val() + '&ym=' + $("#ym").val();
					$.get(url,function(msg){
					// $("#strlength").val(msg);
					$('#nr').html(msg);
					});
				}

			});

			$("#inputstr").keyup(function(){
				// $("#strlength").val($(this).val());

				if ($("#ym").val() == 0) {
					alert('请先输入域名在使用!');
					$('#inputstr').val('');
					return false;
				}else{
					var url = 'zidongneilian.php?url=' + $("#inputstr").val() + '&ym=' + $("#ym").val();
					$.get(url,function(msg){
					// $("#strlength").val(msg);
					$('#nr').html(msg);
					});
				}
			});   

						

			$('textarea').each(function(index, element) {
				var $element = $(element);
				var defaultValue = $element.val();
				$element.focus(function() {
					var actualValue = $element.val();
					if (actualValue == defaultValue) {
						$element.val('');

						var url = 'zidongneilian.php?url=' + $("#strlength").val();
						$.get(url,function(msg){
							// alert(msg);
							$("#strlength").val(msg);
						});


					}
				});
				$element.blur(function() {
					var actualValue = $element.val();
					if (!actualValue) {
						$element.val(defaultValue);
					}
				});
			});


			 
	});